import { describe, expect, it } from 'vitest'
import { defaultSave, parseSave, SAVE_KEY, SaveStore } from '../src/engine/save'
describe('save', () => {
  it('falls back safely and pins the locale to pt-BR', () => {
    expect(parseSave(null)).toEqual(defaultSave())
    expect(parseSave('{nope')).toEqual(defaultSave())
    expect(parseSave(JSON.stringify({ version: 1, locale: 'en', quality: 'ultra', sensitivity: 9 })).locale).toBe('pt-BR')
  })
  it('persists valid local preferences without throwing on storage failures', () => {
    const memory = new Map<string, string>()
    const storage = { getItem: (key: string) => memory.get(key) ?? null, setItem: (key: string, value: string) => void memory.set(key, value) }
    const store = new SaveStore(storage); store.update({ musicVolume: 0.3 })
    expect(JSON.parse(memory.get(SAVE_KEY)!).musicVolume).toBe(0.3)
    const broken = { getItem: () => { throw new Error('denied') }, setItem: () => { throw new Error('quota') } }
    expect(() => new SaveStore(broken).update({ muted: true })).not.toThrow()
  })
})
