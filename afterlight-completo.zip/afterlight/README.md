# Afterlight

**Afterlight** é uma experiência contemplativa 3D em primeira pessoa: caminhe por um prado acima das nuvens, descubra criaturas e memórias, e acorde o guardião silencioso no alto da colina.

## Controles

- **WASD / analógico esquerdo:** caminhar
- **Mouse / analógico direito:** olhar
- **Shift:** correr
- **Espaço:** saltar
- **E / toque:** interagir
- **Esc:** pausar

O jogo é uma experiência estática e solo. Todo o progresso e preferências ficam apenas no navegador.

## Desenvolvimento

```bash
pnpm dev
pnpm test
pnpm build
pnpm smoke
```

O Preview usa `HOST=0.0.0.0` e `PORT=3000`. `pnpm build` valida TypeScript e produz `dist/`.

## Créditos e licenças

O projeto integra o material de referência Faraway como ponto de partida. A fonte visual e os créditos das bibliotecas permanecem descritos nos avisos de fonte em `public/fonts/`; Three.js é MIT e Rapier é Apache-2.0. A marca, interface e apresentação desta versão usam o título **Afterlight**.
